from pydantic import BaseModel
from datetime import datetime
from typing import Optional, List
from app.schemas.user import User

# Убираем импорты Project, Comment, Category чтобы избежать цикла

class TaskBase(BaseModel):
    title: str
    description: Optional[str] = None
    status: Optional[str] = "pending"
    priority: Optional[str] = "medium"
    due_date: Optional[datetime] = None
    project_id: Optional[int] = None

class TaskCreate(TaskBase):
    pass

class TaskUpdate(TaskBase):
    title: Optional[str] = None

class TaskInDBBase(TaskBase):
    id: int
    user_id: int
    created_at: datetime
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True

# Для полной информации о задаче (с отношениями)
class Task(TaskInDBBase):
    user: Optional[User] = None
    # Используем строки вместо импортов для избежания цикла
    project: Optional["Project"] = None
    comments: List["Comment"] = []
    categories: List["Category"] = []

class TaskInDB(TaskInDBBase):
    pass

# Импорты в конце файла для решения циклических зависимостей
from app.schemas.project import Project
from app.schemas.comment import Comment
from app.schemas.category import Category

# Обновляем аннотации после импорта
Task.update_forward_refs(
    Project=Project,
    Comment=Comment,
    Category=Category
)