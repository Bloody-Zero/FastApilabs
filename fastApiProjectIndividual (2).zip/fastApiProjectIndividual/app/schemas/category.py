from pydantic import BaseModel
from datetime import datetime
from typing import Optional, List
from app.schemas.user import User

class CategoryBase(BaseModel):
    name: str
    description: Optional[str] = None

class CategoryCreate(CategoryBase):
    pass

class CategoryUpdate(CategoryBase):
    name: Optional[str] = None

class CategoryInDBBase(CategoryBase):
    id: int
    user_id: int
    created_at: datetime

    class Config:
        from_attributes = True

class Category(CategoryInDBBase):
    user: Optional[User] = None
    tasks: List["Task"] = []

class CategoryInDB(CategoryInDBBase):
    pass

# Импорт в конце
from app.schemas.task import Task
Category.update_forward_refs(Task=Task)