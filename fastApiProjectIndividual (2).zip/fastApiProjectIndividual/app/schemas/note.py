from pydantic import BaseModel
from datetime import datetime
from typing import Optional
from app.schemas.user import User

class NoteBase(BaseModel):
    title: str
    content: Optional[str] = None

class NoteCreate(NoteBase):
    pass

class NoteUpdate(NoteBase):
    title: Optional[str] = None

class NoteInDBBase(NoteBase):
    id: int
    user_id: int
    created_at: datetime
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True

class Note(NoteInDBBase):
    user: Optional[User] = None

class NoteInDB(NoteInDBBase):
    pass