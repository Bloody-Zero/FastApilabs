from pydantic import BaseModel
from datetime import datetime
from typing import Optional, List
from app.schemas.user import User

class ProjectBase(BaseModel):
    title: str
    description: Optional[str] = None
    status: Optional[str] = "active"

class ProjectCreate(ProjectBase):
    pass

class ProjectUpdate(ProjectBase):
    title: Optional[str] = None

class ProjectInDBBase(ProjectBase):
    id: int
    user_id: int
    created_at: datetime
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True

class Project(ProjectInDBBase):
    user: Optional[User] = None
    tasks: List["Task"] = []

class ProjectInDB(ProjectInDBBase):
    pass

# Импорт в конце для избежания цикла
from app.schemas.task import Task
Project.update_forward_refs(Task=Task)