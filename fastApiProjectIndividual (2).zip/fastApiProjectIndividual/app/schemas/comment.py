from pydantic import BaseModel
from datetime import datetime
from typing import Optional
from app.schemas.user import User

class CommentBase(BaseModel):
    content: str

class CommentCreate(CommentBase):
    task_id: int

class CommentUpdate(CommentBase):
    content: Optional[str] = None

class CommentInDBBase(CommentBase):
    id: int
    user_id: int
    task_id: int
    created_at: datetime
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True

class Comment(CommentInDBBase):
    user: Optional[User] = None
    task: Optional["Task"] = None

class CommentInDB(CommentInDBBase):
    pass

# Импорт в конце
from app.schemas.task import Task
Comment.update_forward_refs(Task=Task)