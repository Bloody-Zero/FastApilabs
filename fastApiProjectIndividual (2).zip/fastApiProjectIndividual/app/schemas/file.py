from pydantic import BaseModel
from datetime import datetime
from typing import Optional
from app.schemas.user import User
from app.schemas.task import Task

class FileBase(BaseModel):
    filename: str
    file_path: str
    file_size: Optional[int] = None
    mime_type: Optional[str] = None
    task_id: Optional[int] = None

class FileCreate(FileBase):
    pass

class FileUpdate(FileBase):
    filename: Optional[str] = None
    file_path: Optional[str] = None

class FileInDBBase(FileBase):
    id: int
    user_id: int
    created_at: datetime

    class Config:
        from_attributes = True

class File(FileInDBBase):
    user: Optional[User] = None
    task: Optional[Task] = None

class FileInDB(FileInDBBase):
    pass