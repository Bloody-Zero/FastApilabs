from sqlalchemy.orm import Session
from typing import List
from app.models.note import Note
from app.schemas.note import NoteCreate, NoteUpdate

def get_note(db: Session, note_id: int, user_id: int):
    return db.query(Note).filter(Note.id == note_id, Note.user_id == user_id).first()

def get_notes(db: Session, user_id: int, skip: int = 0, limit: int = 100):
    return db.query(Note).filter(Note.user_id == user_id).offset(skip).limit(limit).all()

def create_note(db: Session, note: NoteCreate, user_id: int):
    db_note = Note(**note.dict(), user_id=user_id)
    db.add(db_note)
    db.commit()
    db.refresh(db_note)
    return db_note

def update_note(db: Session, note_id: int, note_update: NoteUpdate, user_id: int):
    db_note = get_note(db, note_id=note_id, user_id=user_id)
    if db_note:
        update_data = note_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_note, field, value)
        db.commit()
        db.refresh(db_note)
    return db_note

def delete_note(db: Session, note_id: int, user_id: int):
    db_note = get_note(db, note_id=note_id, user_id=user_id)
    if db_note:
        db.delete(db_note)
        db.commit()
    return db_note