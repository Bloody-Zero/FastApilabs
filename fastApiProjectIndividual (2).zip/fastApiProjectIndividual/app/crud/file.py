from sqlalchemy.orm import Session
from typing import List, Optional
from app.models.file import File
from app.schemas.file import FileCreate, FileUpdate

def get_file(db: Session, file_id: int, user_id: int):
    return db.query(File).filter(File.id == file_id, File.user_id == user_id).first()

def get_files(db: Session, user_id: int, skip: int = 0, limit: int = 100, task_id: Optional[int] = None):
    query = db.query(File).filter(File.user_id == user_id)
    if task_id:
        query = query.filter(File.task_id == task_id)
    return query.offset(skip).limit(limit).all()

def create_file(db: Session, file: FileCreate, user_id: int):
    db_file = File(**file.dict(), user_id=user_id)
    db.add(db_file)
    db.commit()
    db.refresh(db_file)
    return db_file

def update_file(db: Session, file_id: int, file_update: FileUpdate, user_id: int):
    db_file = get_file(db, file_id=file_id, user_id=user_id)
    if db_file:
        update_data = file_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_file, field, value)
        db.commit()
        db.refresh(db_file)
    return db_file

def delete_file(db: Session, file_id: int, user_id: int):
    db_file = get_file(db, file_id=file_id, user_id=user_id)
    if db_file:
        db.delete(db_file)
        db.commit()
    return db_file