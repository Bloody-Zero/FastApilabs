from sqlalchemy.orm import Session
from typing import List
from app.models.comment import Comment
from app.schemas.comment import CommentCreate, CommentUpdate

def get_comment(db: Session, comment_id: int, user_id: int):
    return db.query(Comment).filter(Comment.id == comment_id, Comment.user_id == user_id).first()

def get_comments(db: Session, user_id: int, skip: int = 0, limit: int = 100, task_id: Optional[int] = None):
    query = db.query(Comment).filter(Comment.user_id == user_id)
    if task_id:
        query = query.filter(Comment.task_id == task_id)
    return query.offset(skip).limit(limit).all()

def create_comment(db: Session, comment: CommentCreate, user_id: int):
    db_comment = Comment(**comment.dict(), user_id=user_id)
    db.add(db_comment)
    db.commit()
    db.refresh(db_comment)
    return db_comment

def update_comment(db: Session, comment_id: int, comment_update: CommentUpdate, user_id: int):
    db_comment = get_comment(db, comment_id=comment_id, user_id=user_id)
    if db_comment:
        update_data = comment_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_comment, field, value)
        db.commit()
        db.refresh(db_comment)
    return db_comment

def delete_comment(db: Session, comment_id: int, user_id: int):
    db_comment = get_comment(db, comment_id=comment_id, user_id=user_id)
    if db_comment:
        db.delete(db_comment)
        db.commit()
    return db_comment