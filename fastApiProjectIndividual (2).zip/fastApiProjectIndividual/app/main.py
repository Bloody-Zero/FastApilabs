from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import logging

from app.database import SessionLocal, engine
from app.core.config import settings
from app.models.user import User
from app.models.task import Task

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    openapi_url=f"{settings.API_V1_STR}/openapi.json"
)

# Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Базовые эндпоинты
@app.get("/")
async def root():
    return {"message": "FastAPI Application", "version": settings.VERSION}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

@app.get("/api/v1/test-db")
async def test_db():
    try:
        db = SessionLocal()
        result = db.execute("SELECT 1")
        db.close()
        return {"database": "connected"}
    except Exception as e:
        return {"database": "error", "message": str(e)}

# Создание таблиц при запуске
@app.on_event("startup")
async def startup_event():
    try:
        User.metadata.create_all(bind=engine)
        Task.metadata.create_all(bind=engine)
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Error creating database tables: {e}")

# Постепенно добавляем роутеры
try:
    from app.api.endpoints import auth
    app.include_router(auth.router, prefix=settings.API_V1_STR, tags=["auth"])
    logger.info("Auth router loaded successfully")
except ImportError as e:
    logger.warning(f"Auth router not loaded: {e}")

# Простой эндпоинт для тестирования
@app.get("/api/v1/test-auth")
async def test_auth():
    return {"message": "Auth system is available"}