import csv
import json
from io import StringIO
from typing import List, Any
from fastapi.responses import StreamingResponse


def export_to_csv(data: List[Any], filename: str):
    if not data:
        return None

    output = StringIO()
    writer = csv.DictWriter(output, fieldnames=data[0].keys())
    writer.writeheader()
    writer.writerows(data)

    response = StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}.csv"}
    )
    return response


def export_to_json(data: List[Any], filename: str):
    json_data = json.dumps(data, indent=2, default=str)
    response = StreamingResponse(
        iter([json_data]),
        media_type="application/json",
        headers={"Content-Disposition": f"attachment; filename={filename}.json"}
    )
    return response