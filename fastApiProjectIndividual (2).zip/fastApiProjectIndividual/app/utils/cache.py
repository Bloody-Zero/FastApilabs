import redis
import json
from functools import wraps
from app.core.config import settings

redis_client = redis.Redis.from_url(settings.REDIS_URL)


def cache_response(expire: int = 300):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            cache_key = f"{func.__name__}:{str(args)}:{str(kwargs)}"
            cached = redis_client.get(cache_key)
            if cached:
                return json.loads(cached)

            result = await func(*args, **kwargs)
            redis_client.setex(cache_key, expire, json.dumps(result))
            return result

        return wrapper

    return decorator