from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import json

from app.database import get_db
from app.api.dependencies import get_current_active_user
from app.utils.export import export_to_csv, export_to_json
from app.crud.task import get_tasks
from app.crud.project import get_projects
from app.models.user import User

router = APIRouter()


@router.get("/export/tasks/csv")
def export_tasks_csv(
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    tasks = get_tasks(db, user_id=current_user.id, limit=1000)

    task_data = []
    for task in tasks:
        task_data.append({
            "id": task.id,
            "title": task.title,
            "description": task.description,
            "status": task.status,
            "priority": task.priority,
            "due_date": task.due_date,
            "created_at": task.created_at
        })

    return export_to_csv(task_data, "tasks")


@router.get("/export/tasks/json")
def export_tasks_json(
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    tasks = get_tasks(db, user_id=current_user.id, limit=1000)

    task_data = []
    for task in tasks:
        task_data.append({
            "id": task.id,
            "title": task.title,
            "description": task.description,
            "status": task.status,
            "priority": task.priority,
            "due_date": task.due_date.isoformat() if task.due_date else None,
            "created_at": task.created_at.isoformat()
        })

    return export_to_json(task_data, "tasks")


@router.get("/export/projects/csv")
def export_projects_csv(
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    projects = get_projects(db, user_id=current_user.id, limit=1000)

    project_data = []
    for project in projects:
        project_data.append({
            "id": project.id,
            "title": project.title,
            "description": project.description,
            "status": project.status,
            "created_at": project.created_at
        })

    return export_to_csv(project_data, "projects")