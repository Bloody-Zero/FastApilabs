from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Any, Dict

from app.database import get_db
from app.api.dependencies import get_current_admin_user
from app.schemas.user import User
from app.crud.user import get_users, update_user, delete_user
from app.models.user import User as UserModel

router = APIRouter()


@router.get("/admin/users", response_model=List[User])
def admin_get_users(
        skip: int = 0,
        limit: int = 100,
        db: Session = Depends(get_db),
        current_user: UserModel = Depends(get_current_admin_user)
):
    return get_users(db, skip=skip, limit=limit)


@router.post("/admin/users/{user_id}/deactivate")
def admin_deactivate_user(
        user_id: int,
        db: Session = Depends(get_db),
        current_user: UserModel = Depends(get_current_admin_user)
):
    db_user = update_user(db, user_id=user_id, user_update={"is_active": False})
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "User deactivated successfully"}


@router.post("/admin/users/{user_id}/activate")
def admin_activate_user(
        user_id: int,
        db: Session = Depends(get_db),
        current_user: UserModel = Depends(get_current_admin_user)
):
    db_user = update_user(db, user_id=user_id, user_update={"is_active": True})
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "User activated successfully"}


@router.get("/admin/stats")
def admin_stats(
        db: Session = Depends(get_db),
        current_user: UserModel = Depends(get_current_admin_user)
):
    from sqlalchemy import func
    from app.models import User, Task, Project

    user_count = db.query(func.count(User.id)).scalar()
    task_count = db.query(func.count(Task.id)).scalar()
    project_count = db.query(func.count(Project.id)).scalar()

    return {
        "users": user_count,
        "tasks": task_count,
        "projects": project_count
    }