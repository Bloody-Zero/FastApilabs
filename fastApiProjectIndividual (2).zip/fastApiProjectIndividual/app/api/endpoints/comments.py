from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from app.database import get_db
from app.api.dependencies import get_current_active_user
from app.schemas.comment import Comment, CommentCreate, CommentUpdate
from app.crud.comment import get_comment, get_comments, create_comment, update_comment, delete_comment
from app.models.user import User

router = APIRouter()

@router.get("/comments/", response_model=List[Comment])
def read_comments(
    skip: int = 0,
    limit: int = 100,
    task_id: Optional[int] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    comments = get_comments(
        db,
        user_id=current_user.id,
        skip=skip,
        limit=limit,
        task_id=task_id
    )
    return comments

@router.get("/comments/{comment_id}", response_model=Comment)
def read_comment(
    comment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_comment = get_comment(db, comment_id=comment_id, user_id=current_user.id)
    if db_comment is None:
        raise HTTPException(status_code=404, detail="Comment not found")
    return db_comment

@router.post("/comments/", response_model=Comment)
def create_comment_endpoint(
    comment: CommentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    return create_comment(db=db, comment=comment, user_id=current_user.id)

@router.put("/comments/{comment_id}", response_model=Comment)
def update_comment_endpoint(
    comment_id: int,
    comment_update: CommentUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_comment = get_comment(db, comment_id=comment_id, user_id=current_user.id)
    if db_comment is None:
        raise HTTPException(status_code=404, detail="Comment not found")
    return update_comment(db=db, comment_id=comment_id, comment_update=comment_update, user_id=current_user.id)

@router.delete("/comments/{comment_id}")
def delete_comment_endpoint(
    comment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_comment = get_comment(db, comment_id=comment_id, user_id=current_user.id)
    if db_comment is None:
        raise HTTPException(status_code=404, detail="Comment not found")
    delete_comment(db, comment_id=comment_id, user_id=current_user.id)
    return {"message": "Comment deleted successfully"}