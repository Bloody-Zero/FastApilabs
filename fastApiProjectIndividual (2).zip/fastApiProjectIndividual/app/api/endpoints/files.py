from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File
from sqlalchemy.orm import Session
from typing import List, Optional
import os
import shutil

from app.database import get_db
from app.api.dependencies import get_current_active_user
from app.schemas.file import File as FileSchema, FileCreate
from app.crud.file import get_file, get_files, create_file, delete_file
from app.models.user import User

router = APIRouter()

UPLOAD_DIRECTORY = "uploads"

if not os.path.exists(UPLOAD_DIRECTORY):
    os.makedirs(UPLOAD_DIRECTORY)


@router.get("/files/", response_model=List[FileSchema])
def read_files(
        skip: int = 0,
        limit: int = 100,
        task_id: Optional[int] = Query(None),
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    files = get_files(
        db,
        user_id=current_user.id,
        skip=skip,
        limit=limit,
        task_id=task_id
    )
    return files


@router.get("/files/{file_id}", response_model=FileSchema)
def read_file(
        file_id: int,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    db_file = get_file(db, file_id=file_id, user_id=current_user.id)
    if db_file is None:
        raise HTTPException(status_code=404, detail="File not found")
    return db_file


@router.post("/files/upload", response_model=FileSchema)
async def upload_file(
        file: UploadFile = File(...),
        task_id: Optional[int] = None,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    file_location = os.path.join(UPLOAD_DIRECTORY, file.filename)

    with open(file_location, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    file_size = os.path.getsize(file_location)

    file_data = FileCreate(
        filename=file.filename,
        file_path=file_location,
        file_size=file_size,
        mime_type=file.content_type,
        task_id=task_id
    )

    return create_file(db=db, file=file_data, user_id=current_user.id)


@router.delete("/files/{file_id}")
def delete_file_endpoint(
        file_id: int,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    db_file = get_file(db, file_id=file_id, user_id=current_user.id)
    if db_file is None:
        raise HTTPException(status_code=404, detail="File not found")

    # Delete physical file
    if os.path.exists(db_file.file_path):
        os.remove(db_file.file_path)

    delete_file(db, file_id=file_id, user_id=current_user.id)
    return {"message": "File deleted successfully"}