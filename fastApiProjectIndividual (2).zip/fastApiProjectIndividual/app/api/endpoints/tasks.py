from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from app.database import get_db
from app.api.dependencies import get_current_active_user
from app.schemas.task_schemas import Task, TaskCreate, TaskUpdate
from app.crud.task import get_task, get_tasks, create_task, update_task, delete_task
from app.models.user import User

router = APIRouter()

@router.get("/tasks/", response_model=List[Task])
def read_tasks(
    skip: int = 0,
    limit: int = 100,
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    tasks = get_tasks(
        db,
        user_id=current_user.id,
        skip=skip,
        limit=limit,
        status=status,
        priority=priority
    )
    return tasks

@router.get("/tasks/{task_id}", response_model=Task)
def read_task(
    task_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_task = get_task(db, task_id=task_id, user_id=current_user.id)
    if db_task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return db_task

@router.post("/tasks/", response_model=Task)
def create_task_endpoint(
    task: TaskCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    return create_task(db=db, task=task, user_id=current_user.id)