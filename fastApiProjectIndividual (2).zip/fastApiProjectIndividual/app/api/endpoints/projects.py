from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from app.database import get_db
from app.api.dependencies import get_current_active_user
from app.schemas.project import Project, ProjectCreate, ProjectUpdate
from app.crud.project import get_project, get_projects, create_project, update_project, delete_project
from app.models.user import User

router = APIRouter()

@router.get("/projects/", response_model=List[Project])
def read_projects(
    skip: int = 0,
    limit: int = 100,
    status: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    projects = get_projects(
        db,
        user_id=current_user.id,
        skip=skip,
        limit=limit,
        status=status
    )
    return projects

@router.get("/projects/{project_id}", response_model=Project)
def read_project(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_project = get_project(db, project_id=project_id, user_id=current_user.id)
    if db_project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    return db_project

@router.post("/projects/", response_model=Project)
def create_project_endpoint(
    project: ProjectCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    return create_project(db=db, project=project, user_id=current_user.id)

@router.put("/projects/{project_id}", response_model=Project)
def update_project_endpoint(
    project_id: int,
    project_update: ProjectUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_project = get_project(db, project_id=project_id, user_id=current_user.id)
    if db_project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    return update_project(db=db, project_id=project_id, project_update=project_update, user_id=current_user.id)

@router.delete("/projects/{project_id}")
def delete_project_endpoint(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_project = get_project(db, project_id=project_id, user_id=current_user.id)
    if db_project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    delete_project(db, project_id=project_id, user_id=current_user.id)
    return {"message": "Project deleted successfully"}