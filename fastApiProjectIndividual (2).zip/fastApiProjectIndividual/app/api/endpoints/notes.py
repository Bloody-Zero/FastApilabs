from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.api.dependencies import get_current_active_user
from app.schemas.note import Note, NoteCreate, NoteUpdate
from app.crud.note import get_note, get_notes, create_note, update_note, delete_note
from app.models.user import User

router = APIRouter()

@router.get("/notes/", response_model=List[Note])
def read_notes(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    notes = get_notes(
        db,
        user_id=current_user.id,
        skip=skip,
        limit=limit
    )
    return notes

@router.get("/notes/{note_id}", response_model=Note)
def read_note(
    note_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_note = get_note(db, note_id=note_id, user_id=current_user.id)
    if db_note is None:
        raise HTTPException(status_code=404, detail="Note not found")
    return db_note

@router.post("/notes/", response_model=Note)
def create_note_endpoint(
    note: NoteCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    return create_note(db=db, note=note, user_id=current_user.id)

@router.put("/notes/{note_id}", response_model=Note)
def update_note_endpoint(
    note_id: int,
    note_update: NoteUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_note = get_note(db, note_id=note_id, user_id=current_user.id)
    if db_note is None:
        raise HTTPException(status_code=404, detail="Note not found")
    return update_note(db=db, note_id=note_id, note_update=note_update, user_id=current_user.id)

@router.delete("/notes/{note_id}")
def delete_note_endpoint(
    note_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_note = get_note(db, note_id=note_id, user_id=current_user.id)
    if db_note is None:
        raise HTTPException(status_code=404, detail="Note not found")
    delete_note(db, note_id=note_id, user_id=current_user.id)
    return {"message": "Note deleted successfully"}